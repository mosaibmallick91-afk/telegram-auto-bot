"""
Telegram AutoFilter Bot (Premium) - SQLite-ready version

IMPORTANT:
- Fill your secrets in a .env file based on .env.example before running.
- This repo intentionally DOES NOT include your real API keys or tokens.
"""

import os
import re
import asyncio
import logging
import sqlite3
from datetime import datetime
from typing import Optional, List, Dict, Any
import aiohttp

from pyrogram import Client, filters
from pyrogram.types import InlineKeyboardMarkup, InlineKeyboardButton, Message, CallbackQuery

from rapidfuzz import fuzz, process
from dotenv import load_dotenv

# load .env if present
load_dotenv()

# logging
DEBUG = os.getenv("DEBUG", "False").lower() in ("1", "true", "yes")
logging.basicConfig(level=logging.DEBUG if DEBUG else logging.INFO)
log = logging.getLogger(__name__)

# Credentials & config (set these in .env)
API_ID = int(os.getenv("API_ID", "0"))
API_HASH = os.getenv("API_HASH", "")
BOT_TOKEN = os.getenv("BOT_TOKEN", "")
CHANNEL_ID = int(os.getenv("CHANNEL_ID", "0"))

OMDB_API_KEY = os.getenv("OMDB_API_KEY", "")
REQUEST_GROUP_ID = os.getenv("REQUEST_GROUP_ID")  # e.g. -1001234567890
OWNER_ID = int(os.getenv("OWNER_ID", "0"))
MONGO_URI = None  # SQLite-only package
FORCE_SUBSCRIBE_CHANNEL = os.getenv("FORCE_SUBSCRIBE_CHANNEL") or None
RESULT_LIMIT = int(os.getenv("RESULT_LIMIT", "8"))

SHORTENER_PROVIDER_DEFAULT = os.getenv("SHORTENER_PROVIDER", "isgd")

if not (API_ID and API_HASH and BOT_TOKEN and CHANNEL_ID):
    raise SystemExit("Please set API_ID, API_HASH, BOT_TOKEN and CHANNEL_ID environment variables. See .env.example")

app = Client("autofilter_premium", api_id=API_ID, api_hash=API_HASH, bot_token=BOT_TOKEN)

# --- Storage (SQLite) ---
class IndexDB:
    def __init__(self, path="files_index.db"):
        self.conn = sqlite3.connect(path, check_same_thread=False)
        cur = self.conn.cursor()
        cur.execute("""
            CREATE TABLE IF NOT EXISTS files (
                msg_id INTEGER PRIMARY KEY,
                file_id TEXT,
                file_name TEXT,
                caption TEXT,
                date INTEGER,
                size INTEGER,
                language TEXT,
                year TEXT,
                quality TEXT
            )
        """)
        cur.execute("""
            CREATE TABLE IF NOT EXISTS config (
                key TEXT PRIMARY KEY,
                value TEXT
            )
        """)
        self.conn.commit()

    async def upsert(self, msg_id:int, file_id:str, file_name:str, caption:str, date_ts:int, size:int, language:str=None, year:str=None, quality:str=None):
        cur = self.conn.cursor()
        cur.execute("REPLACE INTO files (msg_id, file_id, file_name, caption, date, size, language, year, quality) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                    (msg_id, file_id, file_name, caption or "", date_ts, size, language, year, quality))
        self.conn.commit()

    async def search(self, query:str, limit:int=10, filters:Dict[str,str]=None):
        q = query.lower()
        filters = filters or {}
        cur = self.conn.cursor()
        sql = "SELECT msg_id, file_id, file_name, caption, date, size, language, year, quality FROM files WHERE (LOWER(file_name) LIKE ? OR LOWER(caption) LIKE ?)"
        params = [f"%{q}%", f"%{q}%"]
        if filters.get("language"):
            sql += " AND language = ?"
            params.append(filters["language"])
        if filters.get("year"):
            sql += " AND year = ?"
            params.append(filters["year"])
        if filters.get("quality"):
            sql += " AND quality = ?"
            params.append(filters["quality"])
        sql += " ORDER BY date DESC LIMIT ?"
        params.append(limit)
        cur.execute(sql, tuple(params))
        rows = cur.fetchall()
        res=[]
        for r in rows:
            res.append({"msg_id": r[0], "file_id": r[1], "file_name": r[2], "caption": r[3], "date": r[4], "size": r[5], "language": r[6], "year": r[7], "quality": r[8]})
        return res

    async def all_filenames(self):
        cur = self.conn.cursor()
        cur.execute("SELECT file_name FROM files")
        return [r[0] for r in cur.fetchall()]

    async def get_by_msgid(self, msg_id:int):
        cur = self.conn.cursor()
        cur.execute("SELECT msg_id, file_id, file_name, caption, date, size, language, year, quality FROM files WHERE msg_id = ?", (msg_id,))
        r = cur.fetchone()
        if not r: return None
        return {"msg_id": r[0], "file_id": r[1], "file_name": r[2], "caption": r[3], "date": r[4], "size": r[5], "language": r[6], "year": r[7], "quality": r[8]}

    async def count(self):
        cur = self.conn.cursor()
        cur.execute("SELECT COUNT(*) FROM files")
        return cur.fetchone()[0]

    async def set_config(self, key:str, value:str):
        cur = self.conn.cursor()
        cur.execute("REPLACE INTO config (key, value) VALUES (?, ?)", (key, value))
        self.conn.commit()

    async def get_config(self, key:str, default:Optional[str]=None):
        cur = self.conn.cursor()
        cur.execute("SELECT value FROM config WHERE key = ?", (key,))
        r = cur.fetchone()
        return r[0] if r else default

db = IndexDB()

last_search_results: Dict[int, List[Dict[str,Any]]] = {}

# Tag extraction
LANG_PATTERN = re.compile(r"\\b(english|hindi|tamil|telugu|kannada|malayalam|bengali|urdu)\\b", re.IGNORECASE)
YEAR_PATTERN = re.compile(r"\\b(19[0-9]{2}|20[0-9]{2})\\b")
QUALITY_PATTERN = re.compile(r"\\b(480p|720p|1080p|2160p|4k)\\b", re.IGNORECASE)

def extract_tags(text: str):
    if not text: return (None,None,None)
    lang = None; year = None; quality = None
    m = LANG_PATTERN.search(text)
    if m: lang = m.group(0).title()
    m = YEAR_PATTERN.search(text)
    if m: year = m.group(0)
    m = QUALITY_PATTERN.search(text)
    if m: quality = m.group(0).lower()
    return (lang, year, quality)

# Force subscribe
async def ensure_force_subscribed(user_id:int) -> Optional[str]:
    if not FORCE_SUBSCRIBE_CHANNEL:
        return None
    try:
        chat = await app.get_chat(FORCE_SUBSCRIBE_CHANNEL)
        member = await app.get_chat_member(chat.id, user_id)
        if member.status in ("left", "kicked"):
            link=None
            try:
                invite = await app.create_chat_invite_link(chat.id, member_limit=1)
                link = invite.invite_link
            except Exception:
                link = f"https://t.me/{chat.username}" if chat.username else None
            text = "⚠️ You must join our channel to use this bot."
            if link: text += f"\\nJoin: {link}"
            return text
        return None
    except Exception as e:
        log.warning("Force subscribe check failed: %s", e)
        return None

# OMDb fetch
async def fetch_omdb(title:str):
    if not OMDB_API_KEY:
        return None
    url = f"http://www.omdbapi.com/?apikey={OMDB_API_KEY}&t={aiohttp.helpers.quote(title)}&plot=short"
    try:
        async with aiohttp.ClientSession() as sess:
            async with sess.get(url, timeout=10) as resp:
                if resp.status==200:
                    data = await resp.json()
                    if data.get("Response") == "True":
                        return data
                return None
    except Exception as e:
        log.warning("OMDb fetch error: %s", e)
        return None

# Shortener helpers
async def shorten_url_isgd(url:str) -> Optional[str]:
    api = f"https://is.gd/create.php?format=simple&url={aiohttp.helpers.quote(url)}"
    try:
        async with aiohttp.ClientSession() as sess:
            async with sess.get(api, timeout=8) as resp:
                if resp.status==200:
                    text = await resp.text()
                    if text.startswith("Error:"):
                        return None
                    return text.strip()
    except Exception as e:
        log.warning("is.gd shorten failed: %s", e)
    return None

async def shorten_url_tinyurl(url:str) -> Optional[str]:
    api = f"http://tinyurl.com/api-create.php?url={aiohttp.helpers.quote(url)}"
    try:
        async with aiohttp.ClientSession() as sess:
            async with sess.get(api, timeout=8) as resp:
                if resp.status==200:
                    text = await resp.text()
                    return text.strip()
    except Exception as e:
        log.warning("tinyurl shorten failed: %s", e)
    return None

async def shorten_url(url:str, provider:str="isgd") -> Optional[str]:
    if provider == "tinyurl":
        return await shorten_url_tinyurl(url)
    return await shorten_url_isgd(url)

# Full index
async def full_index(limit:int=2000):
    log.info("Starting full index (limit=%s)...", limit)
    count=0
    async for m in app.search_messages(CHANNEL_ID, limit=limit):
        if m.document or m.video or m.audio or m.photo or m.voice:
            file_name=None; file_id=None; size=0
            if m.document:
                file_name = m.document.file_name
                file_id = m.document.file_id
                size = m.document.file_size or 0
            elif m.video:
                file_name = getattr(m.video, "file_name", None) or (m.caption or "")[:120]
                file_id = m.video.file_id
                size = m.video.file_size or 0
            elif m.audio:
                file_name = getattr(m.audio, "file_name", None) or (m.caption or "")[:120]
                file_id = m.audio.file_id
                size = m.audio.file_size or 0
            elif m.photo:
                file_name = (m.caption or "photo")[:120]
                file_id = m.photo.file_id
            elif m.voice:
                file_name = (m.caption or "voice")[:120]
                file_id = m.voice.file_id
            lang, year, quality = extract_tags((file_name or "") + " " + (m.caption or ""))
            await db.upsert(m.id, file_id, file_name or (m.caption or ""), m.caption or "", int(m.date.timestamp()), size, lang, year, quality)
            count +=1
            if count % 200 == 0:
                log.info("Indexed %s files...", count)
    total = await db.count()
    try:
        await app.send_message(OWNER_ID or CHANNEL_ID, f"✅ Full indexing finished. Total indexed files: {total}")
    except Exception:
        pass

# Auto-index new channel posts
@app.on_message(filters.channel & (filters.document | filters.video | filters.audio | filters.photo | filters.voice))
async def new_channel_post_handler(client:Client, message:Message):
    try:
        file_name=None; file_id=None; size=0
        if message.document:
            file_name = message.document.file_name
            file_id = message.document.file_id
            size = message.document.file_size or 0
        elif message.video:
            file_name = getattr(message.video, "file_name", None) or (message.caption or "")[:120]
            file_id = message.video.file_id
            size = message.video.file_size or 0
        elif message.audio:
            file_name = getattr(message.audio, "file_name", None) or (message.caption or "")[:120]
            file_id = message.audio.file_id
            size = message.audio.file_size or 0
        elif message.photo:
            file_name = (message.caption or "photo")[:120]
            file_id = message.photo.file_id
        elif message.voice:
            file_name = (message.caption or "voice")[:120]
            file_id = message.voice.file_id
        lang, year, quality = extract_tags((file_name or "") + " " + (message.caption or ""))
        await db.upsert(message.id, file_id, file_name or message.caption or '', message.caption or '', int(message.date.timestamp()), size, lang, year, quality)
        log.info(f"Indexed new file: {file_name} (msg_id={message.id})")
    except Exception as e:
        log.exception("Failed to index new channel post: %s", e)

# /start and /help
@app.on_message(filters.command("start") & filters.private)
async def start_cmd(client: Client, message: Message):
    text = "👋 Hi! I'm AutoFilter Bot.\\nSend me a movie or file name and I'll find matching files from the channel."
    await message.reply_text(text)

@app.on_message(filters.command("help") & filters.private)
async def help_cmd(client: Client, message: Message):
    text = (
        "Usage:\\n"
        "- Send any text to search files.\\n"
        "- Click a result button to get the file.\\n"
        "- /shortener_on and /shortener_off to toggle URL shortener (owner only).\\n"
        "Admin commands:\\n"
        "/stats - show indexed count (owner only)"
    )
    await message.reply_text(text)

# /stats
@app.on_message(filters.command("stats") & filters.private)
async def stats_cmd(client: Client, message: Message):
    if OWNER_ID and message.from_user and message.from_user.id != OWNER_ID:
        await message.reply_text("Only owner can use this command.")
        return
    total = await db.count()
    short_enabled = await db.get_config("shortener_enabled", "false")
    await message.reply_text(f"📊 Indexed files: {total}\\n🔗 Shortener enabled: {short_enabled}")

# Shortener toggle
@app.on_message(filters.command("shortener_on") & filters.private)
async def shortener_on_cmd(client: Client, message: Message):
    if not OWNER_ID or message.from_user.id != OWNER_ID:
        await message.reply_text("Only owner can toggle this.")
        return
    await db.set_config("shortener_enabled", "true")
    await db.set_config("shortener_provider", SHORTENER_PROVIDER_DEFAULT)
    await message.reply_text("✅ URL shortener enabled.")

@app.on_message(filters.command("shortener_off") & filters.private)
async def shortener_off_cmd(client: Client, message: Message):
    if not OWNER_ID or message.from_user.id != OWNER_ID:
        await message.reply_text("Only owner can toggle this.")
        return
    await db.set_config("shortener_enabled", "false")
    await message.reply_text("✅ URL shortener disabled.")

# Search handler
@app.on_message(filters.text & filters.private)
async def handle_search(client: Client, message: Message):
    q = message.text.strip()
    if not q:
        await message.reply_text("Please send a search query.")
        return

    fs = await ensure_force_subscribed(message.from_user.id)
    if fs:
        await message.reply_text(fs)
        return

    filenames = await db.all_filenames()
    suggestion = None
    if filenames:
        best = process.extractOne(q, filenames, scorer=fuzz.WRatio)
        if best and best[1] >= 80 and best[0].lower() != q.lower():
            suggestion = best[0]

    filters_obj = {}
    lang, year, quality = extract_tags(q)
    if lang: filters_obj['language'] = lang
    if year: filters_obj['year'] = year
    if quality: filters_obj['quality'] = quality

    results = await db.search(q, limit=RESULT_LIMIT, filters=filters_obj)
    if not results:
        buttons = []
        if suggestion:
            buttons.append([InlineKeyboardButton(f"Did you mean: {suggestion}", callback_data=f"SUGGEST_{suggestion}")])
        buttons.append([InlineKeyboardButton("📩 Request this file", callback_data=f"REQUEST_{q}")])
        await message.reply_text("❌ No results found.", reply_markup=InlineKeyboardMarkup(buttons))
        return

    uid = message.from_user.id
    last_search_results[uid] = results

    buttons = []
    for r in results:
        name = r.get("file_name") or (r.get("caption") or "File")
        snippet = (name[:40] + '...') if len(name) > 43 else name
        buttons.append([InlineKeyboardButton(snippet, callback_data=f"GET_{r['msg_id']}")])

    filter_row = []
    filter_row.append(InlineKeyboardButton("Language", callback_data="FILTER_LANG"))
    filter_row.append(InlineKeyboardButton("Year", callback_data="FILTER_YEAR"))
    filter_row.append(InlineKeyboardButton("Quality", callback_data="FILTER_QUALITY"))

    await message.reply_text(f"🔍 Found {len(results)} matches for: <b>{q}</b>", reply_markup=InlineKeyboardMarkup(buttons + [filter_row]))

# Callback handler
@app.on_callback_query()
async def callbacks_handler(client: Client, callback_query: CallbackQuery):
    data = callback_query.data or ""
    uid = callback_query.from_user.id

    if data.startswith("SUGGEST_"):
        term = data.split("SUGGEST_",1)[1]
        await callback_query.answer()
        # emulate a search message (simple)
        await handle_search(client, Message(**{"chat": callback_query.message.chat, "text": term, "from_user": callback_query.from_user}))
        return

    if data.startswith("REQUEST_"):
        query = data.split("REQUEST_",1)[1]
        await callback_query.answer("Request sent.")
        dest = REQUEST_GROUP_ID or (str(OWNER_ID) if OWNER_ID else None)
        text = f"📩 New Request from @{callback_query.from_user.username or callback_query.from_user.id}\\n🎬 Query: {query}\\n🕓 {datetime.utcnow().isoformat()}"
        if dest:
            try:
                await app.send_message(dest, text)
                await callback_query.message.reply_text("✅ Your request has been sent to the admin.")
            except Exception as e:
                log.exception("Failed to send request: %s", e)
                await callback_query.message.reply_text("⚠️ Failed to send request. Please try again later.")
        else:
            await callback_query.message.reply_text("⚠️ No request destination configured.")
        return

    if data == "FILTER_LANG":
        kb = InlineKeyboardMarkup([[InlineKeyboardButton("English", callback_data="APPLYF_lang:English"), InlineKeyboardButton("Hindi", callback_data="APPLYF_lang:Hindi")],[InlineKeyboardButton("Back", callback_data="FILTER_BACK")]])
        await callback_query.message.edit_reply_markup(kb)
        await callback_query.answer()
        return
    if data == "FILTER_YEAR":
        kb = InlineKeyboardMarkup([[InlineKeyboardButton("2023", callback_data="APPLYF_year:2023"), InlineKeyboardButton("2022", callback_data="APPLYF_year:2022")],[InlineKeyboardButton("Back", callback_data="FILTER_BACK")]])
        await callback_query.message.edit_reply_markup(kb)
        await callback_query.answer()
        return
    if data == "FILTER_QUALITY":
        kb = InlineKeyboardMarkup([[InlineKeyboardButton("480p", callback_data="APPLYF_quality:480p"), InlineKeyboardButton("720p", callback_data="APPLYF_quality:720p")],[InlineKeyboardButton("1080p", callback_data="APPLYF_quality:1080p")],[InlineKeyboardButton("Back", callback_data="FILTER_BACK")]])
        await callback_query.message.edit_reply_markup(kb)
        await callback_query.answer()
        return
    if data == "FILTER_BACK":
        await callback_query.message.edit_reply_markup(None)
        await callback_query.answer()
        return

    if data.startswith("APPLYF_"):
        try:
            _, pair = data.split("APPLYF_",1)
            key, val = pair.split(":",1)
            last = last_search_results.get(uid)
            if not last:
                await callback_query.answer("No previous search cached.", show_alert=True)
                return
            base_query = callback_query.message.text or ""
            qmatch = re.search(r"for: <b>(.*?)</b>", base_query)
            base = qmatch.group(1) if qmatch else ""
            filters = {"language": None, "year": None, "quality": None}
            filters[key] = val
            res = await db.search(base, limit=RESULT_LIMIT, filters=filters)
            if not res:
                await callback_query.answer("No results for that filter.", show_alert=True)
                return
            last_search_results[uid] = res
            buttons = [[InlineKeyboardButton((r.get("file_name")[:30]+"...") if len(r.get("file_name",""))>33 else r.get("file_name"), callback_data=f"GET_{r['msg_id']}")] for r in res]
            await callback_query.message.edit_text(f"🔍 Filtered results for: <b>{base}</b>", reply_markup=InlineKeyboardMarkup(buttons))
            await callback_query.answer()
        except Exception as e:
            log.exception("Filter apply error: %s", e)
            await callback_query.answer("Failed to apply filter.", show_alert=True)
        return

    if data.startswith("GET_"):
        try:
            msg_id = int(data.split("GET_",1)[1])
        except:
            await callback_query.answer("Invalid.", show_alert=True)
            return
        await callback_query.answer("⏳ Preparing file...")
        short_enabled = await db.get_config("shortener_enabled", "false")
        provider = await db.get_config("shortener_provider", SHORTENER_PROVIDER_DEFAULT)
        try:
            await app.copy_message(callback_query.from_user.id, CHANNEL_ID, msg_id)
            if short_enabled == "true":
                tlink = f"https://t.me/c/{str(CHANNEL_ID).lstrip('-100')}/{msg_id}"
                s = await shorten_url(tlink, provider=provider)
                if s:
                    await app.send_message(callback_query.from_user.id, f"🔗 Short link: {s}")
            await callback_query.message.reply_text("✅ File delivered (check your chat).")
        except Exception as e:
            log.exception("Failed to deliver file: %s", e)
            await callback_query.answer("Failed to deliver file. Maybe the bot doesn't have access to the channel message.", show_alert=True)
        return

# Startup
@app.on_connect()
async def startup(client: Client):
    log.info("Bot connected. Running startup tasks...")
    cur = await db.get_config("shortener_enabled", "false")
    if cur is None:
        await db.set_config("shortener_enabled", "false")
    prov = await db.get_config("shortener_provider", SHORTENER_PROVIDER_DEFAULT)
    if prov is None:
        await db.set_config("shortener_provider", SHORTENER_PROVIDER_DEFAULT)
    asyncio.create_task(full_index(limit=2000))

if __name__ == '__main__':
    log.info("Starting AutoFilter Bot...")
    app.run()
