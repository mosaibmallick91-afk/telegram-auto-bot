# Telegram AutoFilter Bot (Premium) - Render-ready (SQLite)

This repository contains a ready-to-deploy Telegram AutoFilter Bot (SQLite-backed).
Fill `.env` from `.env.example` with your credentials and deploy (Render / Railway / Deta).

## Quick steps (Render)
1. Create a GitHub repo and push these files.
2. On Render: New -> Web Service -> Connect repo.
3. Build Command: `pip install -r requirements.txt`
4. Start Command: `python telegram_autofilter_premium.py`
5. Add environment variables in Render (from your .env).

## Notes
- Keep tokens secret. Rotate bot token if exposed.
- SQLite DB file (`files_index.db`) will be created in the app's working directory.
